
package familytree;
/**
 * A sub class of Person.java
 * @author Faiz Syed
 * Student ID: 33243485
 */
class Spouse extends Person //sub class
{
   /**
    * Constructor
    */
    public Spouse() 
    {
        setMemberType("Spouse");
    }
    
}
